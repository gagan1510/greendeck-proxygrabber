print("you are using Hello World library")

# your package information
name = ""
__version__ = ""
author = "Example Author"
author_email = "author@example.com"
url = ""

# import sub packages
from .src.elasticsearch.elasticsearch import ElasticSearch
